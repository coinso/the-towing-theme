<?php
/**
 * Created by PhpStorm.
 * User: ido
 * Date: 2/28/2017
 * Time: 9:24 AM
 */

?>
<section class="hero" id="hp-hero">
    <div class="container">
        <div class="row">
<!--            <div class="col-sm-12-site-title-wrapper text-center">-->
<!--                <h1>--><?php //echo esc_html( get_theme_mod('hero_heading') );?><!--</h1>-->
<!--                <p class="lead" id="hp-hero-description">--><?php //echo esc_html( get_theme_mod('hero_text') );?><!--</p>-->
<!--            </div>-->
        </div>
    </div>
</section>
