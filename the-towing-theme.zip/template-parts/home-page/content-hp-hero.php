<?php
/**
 * Created by PhpStorm.
 * User: ido
 * Date: 2/28/2017
 * Time: 9:24 AM
 */

?>
<section class="hero" id="hp-hero" data-type="background" data-speed="10">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">

            </div>
        </div>
    </div>
    <?php get_template_part('template-parts/globals/content','bouncing-arrow');?>
</section>
