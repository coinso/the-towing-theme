<?php
/**
 * Created by PhpStorm.
 * User: USER
 * Date: 6/1/2018
 * Time: 9:58 AM
 */

?>
<a href="#top" class="scrollup" role="button" title="<?php _e( 'Back to top', 'the-towing-theme' );?>" aria-label="<?php _e( 'Back to top', 'the-towing-theme' );?>" style="display: block;">
    <i class="fa fa-chevron-up" aria-hidden="true"></i><span class="sr-only"><?php _e( 'Back to top', 'the-towing-theme' );?></span>
</a>

