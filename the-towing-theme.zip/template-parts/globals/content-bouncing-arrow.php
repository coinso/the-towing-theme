<?php
/**
 * Created by PhpStorm.
 * User: USER
 * Date: 9/4/2018
 * Time: 06:32 PM
 */
?>

<div class="arrow animated bounce">
	<i class="fa fa-angle-down fa-3x" aria-hidden="true"></i>
</div>
